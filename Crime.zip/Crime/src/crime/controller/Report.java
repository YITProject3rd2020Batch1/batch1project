package crime.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import crime.dao.*;
import crime.model.*;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Report")
public class Report extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int n=1;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   
   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		String rep_auty="Police officer";
		response.setContentType("text/html");
		PrintWriter out= response.getWriter(); 
		
		String rpt_id=request.getParameter("rpt_id");
		String date_rpt=request.getParameter("date_rpt");
		String rpt_det=request.getParameter("rpt_det");
		int com_id=Integer.parseInt(request.getParameter("com_id"));

	    Reportmodel r1=new  Reportmodel();
	    r1.setRpt_id(rpt_id);
	    r1.setDate_rpt(date_rpt);
	    r1.setRpt_det(rpt_det);
	    r1.setRep_auty(rep_auty);
	    r1.setCom_id(com_id);
	    if(ReportDAO.report(r1)==true)
	    {
	    	rd=request.getRequestDispatcher("adminhome.jsp");
	    	rd.forward(request, response);
	    }
	    else
	    {
	    	request.setAttribute("errormsg", "PLEASE ENTER THE CREDENTIALS!! NOT ABLE TO REGISTER");
	    	rd=request.getRequestDispatcher("report.jsp");
	    	rd.forward(request, response);
	    }
		
		
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}


