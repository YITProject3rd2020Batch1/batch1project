package crime.dao;
import java.sql.Connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import crime.model.*;
public class CancelDAO {
	private static Connection con; 
	private static PreparedStatement stmt;
	public static void getConnection()
	{
		 String JdbcURL = "jdbc:mysql://localhost:3306/crimedb?" + "autoReconnect=true&useSSL=false";
	      String Username = "root";
	      String password = "";
	       con = null;      
	       try 
		      {
		    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
		         con = DriverManager.getConnection(JdbcURL, Username, password);
		         
		      } 
		      catch (Exception e) 
		      {
		         e.printStackTrace();
		      }
	 }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }
	  
	  public static boolean cancel(Complaintmodel cancel)
	  {
		  int nor=0;
		  try{
			  getConnection();
			  stmt=con.prepareStatement("update complaint set status=? where com_id=?");
			  stmt.setString(1, cancel.getStatus());
              stmt.setInt(2, cancel.getCom_id());
			 nor= stmt.executeUpdate();
			 closeConnection();
			   if (nor>0)
			   {
				   return true;
			   }
			   else
				   return false;
			    }
			  catch(SQLException e)
			  {
			  e.printStackTrace();
			  return false;
			  }
			  catch(Exception e)
			  {
			  e.printStackTrace();
			  return false;
			  }  	  	  
			  
		  }
	}

