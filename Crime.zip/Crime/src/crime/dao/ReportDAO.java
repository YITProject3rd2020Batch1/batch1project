package crime.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import crime.model.*;

public class ReportDAO {
	private static Connection con; 
	private static PreparedStatement stmt;
	public static void getConnection()
	  {
		  try {
		  Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
		  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/crimeDB","root",""); 
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	  }
		  catch(Exception e)
		  {	  e.printStackTrace();	  }  	  
		  
	  
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }
	  public static boolean report(Reportmodel rep)
	  {
		  int nor=0;
		  try{
			  getConnection();
			   stmt=con.prepareStatement("insert into report values(?,?,?,?,?)");
			  stmt.setString(1, rep.getRpt_id() );
			  stmt.setString(2, rep.getDate_rpt());
			  stmt.setString(3, rep.getRpt_det());
			  stmt.setString(4, rep.getRep_auty());
			  stmt.setInt(5, rep.getCom_id());
			    nor= stmt.executeUpdate();
			 closeConnection();
			   if (nor>0)
			   {
				   return true;
			   }
			   else
				   return false;
			    }
			  catch(SQLException e)
			  {
			  e.printStackTrace();
			  return false;
			  }
			  catch(Exception e)
			  {
			  e.printStackTrace();
			  return false;
			  }  
	  }
			  

}
